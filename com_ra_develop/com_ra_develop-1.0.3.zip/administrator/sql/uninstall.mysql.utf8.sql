DROP TABLE IF EXISTS `#__ra_builds`;
DROP TABLE IF EXISTS `#__ra_extensions`;
DROP TABLE IF EXISTS `#__ra_extension_types`;
DROP TABLE IF EXISTS `#__ra_sub_systems`;