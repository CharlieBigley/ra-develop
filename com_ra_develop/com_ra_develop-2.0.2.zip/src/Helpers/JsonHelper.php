<?php
namespace Ramblers\Component\Ra_develop\Site\Helpers;

use Joomla\CMS\Factory;
use Joomla\Database\ParameterType;

class JsonHelper
{
    /**
     * Execute a curl command to fetch API data
     * @param int $api_site_id ID of the record in api_sites
     * @param string $endpoint The required endpoint URL
     * @param int $verbose Verbose flag (0/1)
     * @return array Decoded response or error info
     */
    public static function fetchApiData($api_site_id, $endpoint, $verbose = 0)
    {
        $db = Factory::getDbo();
        // Get token for api_site_id
        $query = $db->getQuery(true)
            ->select($db->quoteName(['api_token', 'api_url']))
            ->from($db->quoteName('#__api_sites'))
            ->where($db->quoteName('id') . ' = :id')
            ->bind(':id', $api_site_id, ParameterType::INTEGER);
        $db->setQuery($query);
        $site = $db->loadObject();
        if (!$site || empty($site->api_token)) {
            return ['error' => 'API site or token not found'];
        }
        $token = $site->api_token;
        $url = $site->api_url . $endpoint;
        $headers = [
            'Accept: application/vnd.api+json',
            'Content-Type: application/json',
            'X-Joomla-Token: ' . $token,
            'Authorization: Bearer ' . $token
        ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_HEADER, true);
        $response = curl_exec($ch);
        $curl_info = curl_getinfo($ch);
        $curl_error = curl_error($ch);
        curl_close($ch);
        // Split headers/body
        $header_size = $curl_info['header_size'] ?? 0;
        $raw_headers = substr($response, 0, $header_size);
        $body = substr($response, $header_size);
        $decoded = json_decode($body, true);
        if ($verbose) {
            // Log to DB
            $log = [
                'endpoint' => $endpoint,
                'api_site_id' => $api_site_id,
                'headers' => json_encode($headers),
                'raw_headers' => $raw_headers,
                'body' => $body,
                'curl_info' => json_encode($curl_info),
                'curl_error' => $curl_error,
                'decoded' => json_encode($decoded)
            ];
            $columns = array_keys($log);
            $values = array_map([$db, 'quote'], array_values($log));
            $db->setQuery('INSERT INTO #__ra_logfile (' . implode(',', $columns) . ') VALUES (' . implode(',', $values) . ')');
            $db->execute();
        }
        return $decoded ?: ['error' => $curl_error ?: 'No response'];
    }

    /**
     * Display all fields from the first record in the response
     * @param array $response Decoded API response
     * @return array List of field names and values
     */
    public static function displayFields($response)
    {
        if (!isset($response['data'][0])) {
            return ['error' => 'No records found'];
        }
        return $response['data'][0]['attributes'] ?? $response['data'][0];
    }
}
