<?php
/**
 * @version    1.0.12
 * @package    com_ra_develop
 * @author     Charlie Bigley <charlie@bigley.me.uk>
 * @copyright  2026 Charlie Bigley
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Ramblers\Component\Ra_develop\Api\View\Extensions;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\JsonApiView as BaseApiView;

/**
 * The Extensions JSON API view
 *
 * @since  1.0.0
 */
class JsonapiView extends BaseApiView
{
    /**
     * The fields to render item in the documents
     *
     * These fields are exposed when fetching a single extension record.
     * Includes both base table fields and read-only fields from joins.
     *
     * @var    array
     * @since  1.0.0
     */
    protected $fieldsToRenderItem = [
        'id',
        'subsystem_name',  // Read-only: from sub_systems join
        'name',
        'type_name',       // Read-only: from extension_types join
        'max_version_sort',
    ];

    /**
     * The fields to render items in the documents
     *
     * These fields are exposed when fetching multiple extension records.
     * Includes base table fields and joined data for display purposes.
     *
     * @var    array
     * @since  1.0.0
     */
    protected $fieldsToRenderList = [
        'id',
        'subsystem_name',  // Read-only: from sub_systems join
        'name',
        'type_name',       // Read-only: from extension_types join
        'max_version_sort',
    ];
}
